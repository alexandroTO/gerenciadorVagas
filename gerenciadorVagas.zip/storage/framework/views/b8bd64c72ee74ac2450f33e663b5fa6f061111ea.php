

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de instituições cadastrada</h1><br>
<p><a href="<?php echo e(url('contrato/estudante/new')); ?>" class="btn btn-success">Cadastrar</a>


    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Vaga</th>
            <th scope="col">Instituição</th>
            <th scope="col">Estudante</th>
            <th scope="col">Empresa</th>
            <th scope="col">Editar</th>
            <th scope="col">Excluir</th>
            <th scope="col">contrato</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scope="row"><?php echo e($cont->idContrato); ?></th>
            <td><?php echo e($cont->codVaga); ?></td>
            <td><?php echo e($cont->nomeINS); ?></td>
            <td><?php echo e($cont->nomeAlunoEST); ?></td>
            <td><?php echo e($cont->nomeFantasiaEMP); ?></td>
            <td>
                <a href="estudante/<?php echo e($cont->idContrato); ?>/edit" class="btn btn-primary">Editar</a>
            </td>
            <td>
                <form action="estudante/delete/<?php echo e($cont->idContrato); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger">Deletar</button>
                </form>

            </td>
            <td>
                <a href="estudantes/<?php echo e($cont->idContrato); ?>/" class="btn btn-success">Gerar</a>
            </td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\clone\gerenciadorVagas\resources\views/contratoEstudante/list.blade.php ENDPATH**/ ?>