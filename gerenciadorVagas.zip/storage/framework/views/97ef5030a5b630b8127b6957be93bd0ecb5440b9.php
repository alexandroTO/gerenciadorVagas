

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de instituições cadastrada</h1><br>
<p><a href="<?php echo e(url('contrato/empresa/new')); ?>" class="btn btn-success">Cadastrar</a>


    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Empresa</th>
            <th scope="col">Status</th>
            <th scope="col">Editar</th>
            <th scope="col">Excluir</th>
            <th scope="col">contrato</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scope="row"><?php echo e($cont->id); ?></th>
            <td><?php echo e($cont->nomeFantasiaEMP); ?></td>
            <td><?php echo e($cont->status); ?></td>
            <td>
                <a href="empresa/<?php echo e($cont->id); ?>/edit" class="btn btn-primary">Editar</a>
            </td>
            <td>
                <form action="empresa/delete/<?php echo e($cont->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger">Deletar</button>
                </form>

            </td>
            <td>
                <a href="empresas/<?php echo e($cont->id); ?>/" class="btn btn-success">Gerar</a>
            </td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/contratoEmpresa/list.blade.php ENDPATH**/ ?>