

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de estudantes cadastrada</h1><br>
<p><a href="<?php echo e(url('estudante/new')); ?>" class="btn btn-success">Cadastrar</a>


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered table-hover">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nome</th>
            <th scope="col">CPF</th>
            <th scope="col">Contato</th>
            <th scope="col">Curso</th>
            <th scope="col">Periodo</th>
            <th scope="col">Ano fim</th>
            <th scope="col">Editar</th>
            <th scope="col">Excluir</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $estudante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="table-light" align="center">
            <th scope="row"><?php echo e($est->id); ?></th>
            <td ><?php echo e($est->nomeAlunoEST); ?></td>
            <td><?php echo e($est->cpfEST); ?></td>
            <td><?php echo e($est->foneEST); ?></td>
            <td><?php echo e($est->curso); ?></td>
            <td><?php echo e($est->periodo); ?></td>
            <td><?php echo e($est->anoFim); ?></td>
            <td>
                <a href="estudante/<?php echo e($est->id); ?>/edit" class="btn btn-primary">Editar</a>
            </td>
            <td>
                <form action="estudante/delete/<?php echo e($est->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger">Deletar</button>
                </form>

            </td>
        </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/estudante/list.blade.php ENDPATH**/ ?>