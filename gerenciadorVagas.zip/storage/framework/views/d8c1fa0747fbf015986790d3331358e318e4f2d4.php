<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH E:\acertestagios\gerenciador\resources\views/vendor/adminlte/partials/navbar/menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>