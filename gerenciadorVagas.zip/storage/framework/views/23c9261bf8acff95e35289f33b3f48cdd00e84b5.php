

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(Request::is('*/edit')): ?>

<h5>Editar</h5>
<?php else: ?>
<h5>Cadastrar</h5>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="padding: 25px;">
                <div class="card-header"><a href="<?php echo e(url('vaga')); ?>" class="btn btn-primary">Voltar</a></div>
                <?php if(Request::is('*/edit')): ?>
                <form action="<?php echo e(url('vaga/update')); ?>/<?php echo e($vaga->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="codigoEmpresa" class="form-label">Empresa:</label>
                        <input type="text" name="codigoEmpresa" class="form-control" value="<?php echo e($vaga->codEmpresa); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição da vaga:</label>
                        <textarea name="descricao" id="descricao" cols="30" rows="10"><?php echo e($vaga->descricao); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tipoVaga" class="form-label">Tipo de vaga:</label>
                        <input type="text" name="tipoVaga" class="form-control" value="<?php echo e($vaga->tipoVaga); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="jornada" class="form-label">Hórario de trabalho:</label>
                        <input type="text" name="jornada" class="form-control" value="<?php echo e($vaga->jornada); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="curso" class="form-label">Curso:</label>
                        <input type="text" name="curso" class="form-control" value="<?php echo e($vaga->curso); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="periodo" class="form-label">Periodo minimo:</label>
                        <input type="text" name="periodo" class="form-control" value="<?php echo e($vaga->periodo); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="auxilio" class="form-label">Valor do auxilio:</label>
                        <input type="text" name="auxilio" class="form-control" value="<?php echo e($vaga->auxilio); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="auxTransporteVAG" class="form-label">Valor do auxilio de transporte:</label>
                        <input type="text" name="auxTransporteVAG" class="form-control" value="<?php echo e($vaga->auxTransporteVAG); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="setorVAG" class="form-label">Setor na empresa:</label>
                        <input type="text" name="setorVAG" class="form-control" value="<?php echo e($vaga->setorVAG); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="lotacaoVAG" class="form-label">Lotação:</label>
                        <input type="text" name="lotacaoVAG" class="form-control" value="<?php echo e($vaga->lotacaoVAG); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="vigenciaVAG" class="form-label">Vigencia:</label>
                        <input type="text" name="vigenciaVAG" class="form-control" value="<?php echo e($vaga->vigenciaVAG); ?>">
                    </div>


                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(url('vaga/add')); ?>" method="post" class='form1'>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="codigoEmpresa">Empresa:</label>
                        <select class="form-control" name="codigoEmpresa">
                            <option></option>
                            <?php $__currentLoopData = $empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->id); ?> - <?php echo e($emp->nomeFantasiaEMP); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição da vaga:</label>
                        <textarea name="descricao" id="descricao" cols="30" rows="10"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tipoVaga" class="form-label">Tipo de vaga:</label>
                        <input type="text" name="tipoVaga" class="form-control" placeholder="Integral ou meio periodo">
                    </div>
                    <div class="mb-3">
                        <label for="jornada" class="form-label">Hórario de trabalho:</label>
                        <input type="text" name="jornada" class="form-control" placeholder="EX: seg a sex 08:00 as 13:00">
                    </div>
                    <div class="mb-3">
                        <label for="curso" class="form-label">Curso:</label>
                        <input type="text" name="curso" class="form-control" placeholder="Nome do curso">
                    </div>
                    <div class="mb-3">
                        <label for="periodo" class="form-label">Periodo minimo:</label>
                        <input type="text" name="periodo" class="form-control" placeholder="Periodo minimo de estudo para se candidatar">
                    </div>
                    <div class="mb-3">
                        <label for="auxilio" class="form-label">Valor do auxilio:</label>
                        <input type="text" name="auxilio" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="auxTransporteVAG" class="form-label">Valor do auxilio de transporte:</label>
                        <input type="text" name="auxTransporteVAG" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="setorVAG" class="form-label">Setor na empresa:</label>
                        <input type="text" name="setorVAG" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="lotacaoVAG" class="form-label">Lotação:</label>
                        <input type="text" name="lotacaoVAG" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="vigenciaVAG" class="form-label">Vigencia:</label>
                        <input type="text" name="vigenciaVAG" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success">Cadastrar</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.tiny.cloud/1/bcgvi6e011xw466lirf3h7pss4s14dtn6wzwv5a5emywxwrw/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
  selector: 'textarea#descricao',
  height: 500,
  
  menubar: false,
  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste code help wordcount'
  ],
  toolbar: 'undo redo | formatselect | ' +
  'bold italic backcolor | alignleft aligncenter ' +
  'alignright alignjustify | bullist numlist outdent indent | ' +
  'removeformat | help',
  content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/vaga/form.blade.php ENDPATH**/ ?>