

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Lista de vagas cadastrada</h1><br>
<p><a href="<?php echo e(url('vaga/new')); ?>" class="btn btn-success">Cadastrar</a>


    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead class="thead-dark">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Empresa</th>
            <th scope="col">Tipo da vaga</th>
            <th scope="col">Hórario</th>
            <th scope="col">Curso</th>
            <th scope="col">Periodo</th>
            <th scope="col">Auxilio</th>
            <th scope="col">Editar</th>
            <th scope="col">Excluir</th>
        </tr>
    </thead>
    <tbody>
            
        <?php $__currentLoopData = $vaga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

            <th scope="row"><?php echo e($vg->id); ?></th>
            <td><?php echo e($vg->nomeFantasiaEMP); ?></td>
            <td><?php echo e($vg->tipoVaga); ?></td>
            <td><?php echo e($vg->jornada); ?></td>
            <td><?php echo e($vg->curso); ?></td>
            <td><?php echo e($vg->periodo); ?></td>
            <td><?php echo e($vg->auxilio); ?></td>
            <td>
                <a href="vaga/<?php echo e($vg->id); ?>/edit" class="btn btn-primary">Editar</a>
            </td>
            <td>
                <form action="vaga/delete/<?php echo e($vg->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger">Deletar</button>
                </form>

            </td>
        </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/vaga/list.blade.php ENDPATH**/ ?>