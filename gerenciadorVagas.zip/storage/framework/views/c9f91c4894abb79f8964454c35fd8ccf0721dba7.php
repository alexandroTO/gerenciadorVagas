

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(Request::is('*/edit')): ?>
<h5>Editar</h5>

<?php else: ?>
<h5>Cadastrar</h5>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="padding: 25px;">
                <div class="card-header"><a href="<?php echo e(url('estudante')); ?>" class="btn btn-primary">Voltar</a></div>
                <?php if(Request::is('*/edit')): ?>
                <form action="<?php echo e(url('estudante/update')); ?>/<?php echo e($estudante->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="dataNascimento" class="form-label">Data Naascimento:</label>
                        <input type="text" name="dataNascimento" class="form-control" value="<?php echo e($estudante->dataNascimentoEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="fone" class="form-label">Fone:</label>
                        <input type="text" name="fone" class="form-control" value="<?php echo e($estudante->foneEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="rg" class="form-label">RG:</label>
                        <input type="text" name="rg" class="form-control" value="<?php echo e($estudante->rgEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="cpf" class="form-label">CPF:</label>
                        <input type="text" name="cpf" class="form-control" value="<?php echo e($estudante->cpfEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="rua" class="form-label">Rua:</label>
                        <input type="text" name="rua" class="form-control" value="<?php echo e($estudante->ruaEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="num" class="form-label">Numero:</label>
                        <input type="text" name="num" class="form-control" value="<?php echo e($estudante->numEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="bairro" class="form-label">Bairro:</label>
                        <input type="text" name="bairro" class="form-control" value="<?php echo e($estudante->bairroEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="cidade">Cidade:</label>
                        <input type="text" name="cidade" class="form-control" value="<?php echo e($estudante->cidadeEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="estadoEST">Estado:</label>
                        <input type="text" name="estadoEST" class="form-control" value="<?php echo e($estudante->estadoEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="cep">Cep:</label>
                        <input type="text" name="cep" class="form-control" value="<?php echo e($estudante->cepEST); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="curso">Curso:</label>
                        <input type="text" name="curso" class="form-control" value="<?php echo e($estudante->curso); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="turno">Turno:</label>
                        <input type="text" name="turno" class="form-control" value="<?php echo e($estudante->turno); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="periodo">Periodo:</label>
                        <input type="text" name="periodo" class="form-control" value="<?php echo e($estudante->periodo); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="anoInicio">Iniciou em:</label>
                        <input type="text" name="anoInicio" class="form-control" value="<?php echo e($estudante->anoInicio); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="anoFim">Finaliza em:</label>
                        <input type="text" name="anoFim" class="form-control" value="<?php echo e($estudante->anoFim); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="codInstituicao">Instituição</label>
                        <select class="form-control" name="codInstituicao">
                                                
                            <option value="<?php echo e($instituicao->id); ?>" selected><?php echo e($instituicao->nome); ?></option>
                            
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(url('estudante/add')); ?>" method="post" class='form1'>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome:</label>
                        <input type="text" name="nomeAlunoEST" class="form-control" placeholder="Nome do aluno">
                    </div>
                    <div class="mb-3">
                        <label for="dataNascimentoEST" class="form-label">Data Nascimento:</label>
                        <input type="date" name="dataNascimentoEST" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label for="fone" class="form-label">Fone:</label>
                        <input type="text" name="foneEST" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="rg" class="form-label">RG:</label>
                        <input type="text" name="rgEST" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="cpf" class="form-label">CPF:</label>
                        <input type="text" name="cpfEST" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="rua" class="form-label">Rua:</label>
                        <input type="text" name="ruaEST" class="form-control" placeholder="Rua">
                    </div>
                    <div class="mb-3">
                        <label for="num" class="form-label">Numero:</label>
                        <input type="text" name="numEST" class="form-control" placeholder="Numero">
                    </div>
                    <div class="mb-3">
                        <label for="bairro" class="form-label">Bairro:</label>
                        <input type="text" name="bairroEST" class="form-control" placeholder="Bairro">
                    </div>
                    <div class="mb-3">
                        <label for="cidade">Cidade:</label>
                        <input type="text" name="cidadeEST" class="form-control" placeholder="Cidade">
                    </div>
                    <div class="mb-3">
                        <label for="estado">Estado:</label>
                        <select id="estado" name="estadoEST" class="form-control">
                            <option value="AC">Acre</option>
                            <option value="AL">Alagoas</option>
                            <option value="AP">Amapá</option>
                            <option value="AM">Amazonas</option>
                            <option value="BA">Bahia</option>
                            <option value="CE">Ceará</option>
                            <option value="DF">Distrito Federal</option>
                            <option value="ES">Espírito Santo</option>
                            <option value="GO">Goiás</option>
                            <option value="MA">Maranhão</option>
                            <option value="MT">Mato Grosso</option>
                            <option value="MS">Mato Grosso do Sul</option>
                            <option value="MG">Minas Gerais</option>
                            <option value="PA">Pará</option>
                            <option value="PB">Paraíba</option>
                            <option value="PR">Paraná</option>
                            <option value="PE">Pernambuco</option>
                            <option value="PI">Piauí</option>
                            <option value="RJ">Rio de Janeiro</option>
                            <option value="RN">Rio Grande do Norte</option>
                            <option value="RS">Rio Grande do Sul</option>
                            <option value="RO">Rondônia</option>
                            <option value="RR">Roraima</option>
                            <option value="SC">Santa Catarina</option>
                            <option value="SP">São Paulo</option>
                            <option value="SE">Sergipe</option>
                            <option value="TO">Tocantins</option>
                            <option value="EX">Estrangeiro</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="cep">Cep:</label>
                        <input type="text" name="cepEST" class="form-control" placeholder="Cep">
                    </div>
                    <div class="mb-3">
                        <label for="curso">Curso:</label>
                        <input type="text" name="curso" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="turno">Turno:</label>
                        <input type="text" name="turno" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="periodo">Periodo:</label>
                        <input type="text" name="periodo" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="anoInicio">Iniciou em:</label>
                        <input type="text" name="anoInicio" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="anoFim">Finaliza em:</label>
                        <input type="text" name="anoFim" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="codInstituicao">Instituição</label>
                        <select class="form-control" name="codInstituicao">
                            <option></option>
                            <?php $__currentLoopData = $instituicao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($inst->id); ?>"><?php echo e($inst->id); ?> - <?php echo e($inst->nomeINS); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success">Cadastrar</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/estudante/form.blade.php ENDPATH**/ ?>