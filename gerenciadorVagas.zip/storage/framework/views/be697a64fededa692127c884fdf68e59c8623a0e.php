

<?php $__env->startSection('title', 'Instituição'); ?>

<?php $__env->startSection('content_header'); ?>
<?php if(Request::is('*/edit')): ?>
<h5>Editar</h5>
<?php else: ?>
<h5>Cadastrar</h5>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card" style="padding: 25px;">
                <div class="card-header"><a href="<?php echo e(url('contrato/empresa')); ?>" class="btn btn-primary">Voltar</a></div>
                <?php if(Request::is('*/edit')): ?>
                <?php $__currentLoopData = $contrato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(url('contrato/empresa/update')); ?>/<?php echo e($cont->idContrato); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nomeFantasia" class="form-label">Empresa:</label>
                        <input type="text" name="nomeFantasia" class="form-control" value="<?php echo e($cont->nomeFantasiaEMP); ?>">
                    </div>
                                       
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <form action="<?php echo e(url('contrato/empresa/add')); ?>" method="post" class='form1'>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="codInstituicao">Empresa</label>
                        <select class="form-control" name="codEmpresa">
                            <option></option>
                            <?php $__currentLoopData = $empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->id); ?> - <?php echo e($emp->nomeFantasiaEMP); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-success">Cadastrar</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\acertestagios\gerenciador\resources\views/contratoEmpresa/form.blade.php ENDPATH**/ ?>